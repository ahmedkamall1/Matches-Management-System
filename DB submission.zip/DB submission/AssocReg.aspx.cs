﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GUCDB
{
    public partial class AssocReg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void AMR2_Click(object sender, EventArgs e)
        {
            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);
            string name = AMN.Text;
            string username = AMU.Text;
            string password = AMP.Text;
            SqlCommand check = new SqlCommand("checkUser", conn);
            check.CommandType = CommandType.StoredProcedure;
            check.Parameters.Add(new SqlParameter("@u", username));
            SqlParameter success = check.Parameters.Add("@o", System.Data.SqlDbType.Int);
            success.Direction = ParameterDirection.Output;
            conn.Open();
            check.ExecuteNonQuery();
            conn.Close();
            if (name == ""|| password==""||username==""||success.Value.ToString()=="0")
            {
                Response.Write("Invalid username");
            }
            else
            {
                SqlCommand addAssocproc = new SqlCommand("addAssociationManager", conn);
                addAssocproc.CommandType = CommandType.StoredProcedure;
                addAssocproc.Parameters.Add(new SqlParameter("@N", name));
                addAssocproc.Parameters.Add(new SqlParameter("@U", username));
                addAssocproc.Parameters.Add(new SqlParameter("@P", password));
                conn.Open();
                addAssocproc.ExecuteNonQuery();
                conn.Close();
                Response.Redirect("AssocManager.aspx");
            }
        }
    }
}