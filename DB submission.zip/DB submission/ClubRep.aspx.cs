﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace GUCDB
{
    public partial class ClubRep : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            {
                string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
                SqlConnection conn = new SqlConnection(CONNSTR);
                
                string sname = hostreqsname.Text;
                string St = hostreqstime.Text;
                string user = Session["user"].ToString();

                DateTime Std =
                DateTime.ParseExact(St, "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);
                SqlCommand check = new SqlCommand("getClub", conn);
                check.CommandType = CommandType.StoredProcedure;
                check.Parameters.Add(new SqlParameter("@u", user));
                string c_name = "";
                conn.Open();
                SqlDataReader r1 = check.ExecuteReader(CommandBehavior.CloseConnection);

                while (r1.Read())
                {
                    c_name = r1.GetString(r1.GetOrdinal("name"));
                }
                conn.Close();
                SqlCommand check2 = new SqlCommand("checkStadium", conn);
                check2.CommandType = CommandType.StoredProcedure;
                check2.Parameters.Add(new SqlParameter("@n", sname));
                SqlParameter success2 = check2.Parameters.Add("@o", System.Data.SqlDbType.Int);
                success2.Direction = ParameterDirection.Output;
                conn.Open();
                check2.ExecuteNonQuery();
                conn.Close();
                if (sname == ""||success2.Value.ToString()=="0")
                {
                    Response.Write("Stadium not available");
                }
                else
                {
                    SqlCommand hostreqproc = new SqlCommand("addHostRequest", conn);
                    hostreqproc.CommandType = CommandType.StoredProcedure;
                    hostreqproc.Parameters.Add(new SqlParameter("@C", c_name));
                    hostreqproc.Parameters.Add(new SqlParameter("@S", sname));
                    hostreqproc.Parameters.Add(new SqlParameter("@t", Std));

                    conn.Open();
                    hostreqproc.ExecuteNonQuery();
                    conn.Close();
                    Response.Write("request sent");
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);

            string user = Session["user"].ToString();
        
            SqlCommand getId = new SqlCommand("getClubId", conn);
            getId.CommandType = CommandType.StoredProcedure;
            getId.Parameters.Add(new SqlParameter("@u", user));
            string c_name ="" ;
            conn.Open();
            SqlDataReader r1 =getId.ExecuteReader(CommandBehavior.CloseConnection);
            while(r1.Read())
            {
                c_name = r1.GetString(r1.GetOrdinal("name"));
            }
            
           // Response.Write(c_id);
            conn.Close();
            SqlCommand viewMatch = new SqlCommand("select * from club  where name='"+c_name+"'", conn);
            
            conn.Open();
            
            
            

            SqlDataReader r = viewMatch.ExecuteReader(CommandBehavior.CloseConnection);
            while (r.Read())
            {
                string l = r.GetString(r.GetOrdinal("location"));
                string n = r.GetString(r.GetOrdinal("name"));
                int id = r.GetInt32(r.GetOrdinal("id"));
                Label loc = new Label();
                Label name = new Label();
                Label cid = new Label();
                loc.Text = l + " ";
                name.Text = " " + n + " ";
                cid.Text = id.ToString() + " ";


                form1.Controls.Add(name);
                form1.Controls.Add(loc);
                form1.Controls.Add(cid);
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);

            string user = Session["user"].ToString();

            SqlCommand getId = new SqlCommand("getClubId", conn);
            getId.CommandType = CommandType.StoredProcedure;
            getId.Parameters.Add(new SqlParameter("@u", user));
            string c_name = "";
            conn.Open();
            SqlDataReader r1 = getId.ExecuteReader(CommandBehavior.CloseConnection);
            while (r1.Read())
            {
                c_name = r1.GetString(r1.GetOrdinal("name"));
            }
            // Response.Write(c_id);
            conn.Close();
            SqlCommand viewMatch = new SqlCommand("select c1.name as club1 ,c2.name as club2 ,m.startTime as s ,m.endTime as e from match m inner join club c1 on c1.id=m.hostId inner join club c2 on c2.id=guestId where m.startTime>current_TimeStamp and( c1.name='" + c_name + "'or c2.name='"+ c_name + "')", conn);

            conn.Open();

            SqlDataReader r = viewMatch.ExecuteReader(CommandBehavior.CloseConnection);
            while (r.Read())
            {
                string c1 = r.GetString(r.GetOrdinal("club1"));
                string c2 = r.GetString(r.GetOrdinal("club2"));
                DateTime start = r.GetDateTime(r.GetOrdinal("s"));
                DateTime end = r.GetDateTime(r.GetOrdinal("e"));
                Label host = new Label();
                Label guest = new Label();
                Label st = new Label();
                Label en = new Label();
                host.Text = c1 + " VS ";
                guest.Text = c2;
                st.Text = " start:" + start.ToString();
                en.Text = " end:" + end.ToString() + " | ";

                form1.Controls.Add(host);
                form1.Controls.Add(guest);
                form1.Controls.Add(st);
                form1.Controls.Add(en);

            }
            
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);
            DateTime Std =
                DateTime.ParseExact(dt.Text, "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);
            SqlCommand viewSt = new SqlCommand("select s.name ,s.location,s.capacity from stadium s where not exists(select stadiumId from match where startTime ='"+ Std+"' and stadiumId = s.id)", conn);
            conn.Open();

            SqlDataReader r = viewSt.ExecuteReader(CommandBehavior.CloseConnection);
            while (r.Read())
            {
                string name = r.GetString(r.GetOrdinal("name"));
                string location = r.GetString(r.GetOrdinal("location"));
                int cap = r.GetInt32(r.GetOrdinal("capacity"));
                Label nam = new Label();
                Label loc = new Label();
               
                Label ca = new Label();
                nam.Text = name + "  ";
                loc.Text = location;
               
                ca.Text = cap.ToString() + " | ";

                form1.Controls.Add(nam);
                form1.Controls.Add(loc);
                form1.Controls.Add(ca);
                

            }

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }