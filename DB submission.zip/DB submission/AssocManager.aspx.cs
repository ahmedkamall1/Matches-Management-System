﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Runtime.Remoting.Messaging;
using System.Configuration;
using System.Xml.Linq;

namespace GUCDB
{
    public partial class AssocManager : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);
            string hname = HN.Text;
            string gname = GN.Text;


            string St = ST.Text;
            string Et = ET.Text;

            DateTime Std =
                DateTime.ParseExact(St, "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);
            DateTime Etd =
               DateTime.ParseExact(Et, "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);
            SqlCommand check = new SqlCommand("checkClub", conn);
            check.CommandType = CommandType.StoredProcedure;
            check.Parameters.Add(new SqlParameter("@n", hname));
            SqlParameter success = check.Parameters.Add("@o", System.Data.SqlDbType.Int);
            success.Direction = ParameterDirection.Output;
            conn.Open();
            check.ExecuteNonQuery();
            conn.Close();

            SqlCommand check2 = new SqlCommand("checkClub", conn);
            check2.CommandType = CommandType.StoredProcedure;
            check2.Parameters.Add(new SqlParameter("@n", gname));
            SqlParameter success2 = check2.Parameters.Add("@o", System.Data.SqlDbType.Int);
            success2.Direction = ParameterDirection.Output;
            conn.Open();
            check2.ExecuteNonQuery();
            conn.Close();


            SqlCommand check3 = new SqlCommand("checkclubAvai", conn);
            check3.CommandType = CommandType.StoredProcedure;
            check3.Parameters.Add(new SqlParameter("@n", gname));
            check3.Parameters.Add(new SqlParameter("@s", Std));
            SqlParameter success3 = check3.Parameters.Add("@o", System.Data.SqlDbType.Int);
            success3.Direction = ParameterDirection.Output;
            conn.Open();
            check3.ExecuteNonQuery();
            conn.Close();

            SqlCommand check4= new SqlCommand("checkclubAvai", conn);
            check4.CommandType = CommandType.StoredProcedure;
            check4.Parameters.Add(new SqlParameter("@n", hname));
            check4.Parameters.Add(new SqlParameter("@s", Std));
            SqlParameter success4 = check4.Parameters.Add("@o", System.Data.SqlDbType.Int);
            success4.Direction = ParameterDirection.Output;
            conn.Open();
            check4.ExecuteNonQuery();
            conn.Close();
            if (hname == "" || gname == ""||success.Value.ToString()=="0" || success2.Value.ToString() == "0" || success3.Value.ToString() == "0" || success4.Value.ToString() == "0")
            {
                Response.Write("Clubs are not available");
            }
            else
            {
                SqlCommand Addmatchproc = new SqlCommand("addNewMatch", conn);
                Addmatchproc.CommandType = CommandType.StoredProcedure;

                Addmatchproc.Parameters.Add(new SqlParameter("@H", hname));
                Addmatchproc.Parameters.Add(new SqlParameter("@G", gname));
                Addmatchproc.Parameters.Add(new SqlParameter("@S", Std));
                Addmatchproc.Parameters.Add(new SqlParameter("@E", Etd));
                conn.Open();
                Addmatchproc.ExecuteNonQuery();
                conn.Close();
                Response.Write("Match added");
            }
        }

        protected void HND_TextChanged(object sender, EventArgs e)
        {
            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);
            string hname = HND.Text;
            string gname = GND.Text;


            string St = SD.Text;
            string Et = ED.Text;
            SqlCommand check = new SqlCommand("checkClub", conn);
            check.CommandType = CommandType.StoredProcedure;
            check.Parameters.Add(new SqlParameter("@n", hname));
            SqlParameter success = check.Parameters.Add("@o", System.Data.SqlDbType.Int);
            success.Direction = ParameterDirection.Output;
            conn.Open();
            check.ExecuteNonQuery();
            conn.Close();

            SqlCommand check2 = new SqlCommand("checkClub", conn);
            check2.CommandType = CommandType.StoredProcedure;
            check2.Parameters.Add(new SqlParameter("@n", gname));
            SqlParameter success2 = check2.Parameters.Add("@o", System.Data.SqlDbType.Int);
            success2.Direction = ParameterDirection.Output;
            conn.Open();
            check2.ExecuteNonQuery();
            conn.Close();


            if (hname == "" || gname == ""|| success.Value.ToString() == "0" || success2.Value.ToString() == "0")
            {
                Response.Write("clubs not available");
            }
            else
            {
                SqlCommand Deletematchproc = new SqlCommand("deleteMatch", conn);
                Deletematchproc.CommandType = CommandType.StoredProcedure;
                Deletematchproc.Parameters.Add(new SqlParameter("@H", hname));
                Deletematchproc.Parameters.Add(new SqlParameter("@G", gname));

                conn.Open();
                Deletematchproc.ExecuteNonQuery();
                conn.Close();
                Response.Redirect("Successful.aspx");
            }
        }
       

        protected void Button3_Click(object sender, EventArgs e)
        {


            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);
            
            
            
                SqlCommand viewMatch = new SqlCommand("select * from allMatches where startTime > Current_Timestamp", conn);
               // viewMatch.CommandType = CommandType.StoredProcedure;
               
                conn.Open();
            // viewMatch.ExecuteNonQuery();
            //conn.Close();
            //Response.Redirect("Successful.aspx");
            SqlDataReader r = viewMatch.ExecuteReader(CommandBehavior.CloseConnection);
            while (r.Read())
            {
                string h = r.GetString(r.GetOrdinal("club1"));
                string g = r.GetString(r.GetOrdinal("club2"));
                DateTime start = r.GetDateTime(r.GetOrdinal("starttime"));
                DateTime end = r.GetDateTime(r.GetOrdinal("endtime"));
                Label host = new Label();
                Label guest = new Label();
                Label start_time = new Label();
                Label end_time = new Label();
                host.Text = h +" VS ";
                guest.Text = g;
                start_time.Text =" start:"+ start.ToString();
                end_time.Text =" end:"+ end.ToString()+ " | ";

                form1.Controls.Add(host);
                form1.Controls.Add(guest);
                form1.Controls.Add(start_time);
                form1.Controls.Add(end_time);




            }






        }

        protected void Button6_Click(object sender, EventArgs e)
        {

            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);



            SqlCommand viewMatch = new SqlCommand("select * from allMatches where endTime <Current_Timestamp", conn);
            // viewMatch.CommandType = CommandType.StoredProcedure;

            conn.Open();
            // viewMatch.ExecuteNonQuery();
            //conn.Close();
            //Response.Redirect("Successful.aspx");
            SqlDataReader r = viewMatch.ExecuteReader(CommandBehavior.CloseConnection);
            while (r.Read())
            {
                string h = r.GetString(r.GetOrdinal("club1"));
                string g = r.GetString(r.GetOrdinal("club2"));
                DateTime start = r.GetDateTime(r.GetOrdinal("starttime"));
                DateTime end = r.GetDateTime(r.GetOrdinal("endtime"));
                Label host = new Label();
                Label guest = new Label();
                Label start_time = new Label();
                Label end_time = new Label();
                host.Text = h + " VS ";
                guest.Text = g;
                start_time.Text = " start:" + start.ToString();
                end_time.Text = " end:" + end.ToString() + " | ";

                form1.Controls.Add(host);
                form1.Controls.Add(guest);
                form1.Controls.Add(start_time);
                form1.Controls.Add(end_time);




            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {

            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);



            SqlCommand viewMatch = new SqlCommand("select * from clubsNeverMatched", conn);
            
            conn.Open();
        
            SqlDataReader r = viewMatch.ExecuteReader(CommandBehavior.CloseConnection);
            while (r.Read())
            {
                string h = r.GetString(r.GetOrdinal("c1"));
                string g = r.GetString(r.GetOrdinal("c2"));
                Label host = new Label();
                Label guest = new Label();
                host.Text = h + " VS ";
                guest.Text = g +"|";
               

                form1.Controls.Add(host);
                form1.Controls.Add(guest);
               




            }
        }

        protected void HN_TextChanged(object sender, EventArgs e)
        {

        }
    }
}