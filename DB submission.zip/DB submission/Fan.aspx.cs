﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GUCDB
{
    public partial class Fan : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            {
                string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
                SqlConnection conn = new SqlConnection(CONNSTR);
                string hname = thname.Text;
                string gname = tgname.Text;
                string St = tst.Text;
                string user = Session["user"].ToString();
                DateTime Std =
                    DateTime.ParseExact(St, "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);
                SqlCommand check2 = new SqlCommand("checkmatch", conn);
                check2.CommandType = CommandType.StoredProcedure;
                check2.Parameters.Add(new SqlParameter("@h", hname));
                check2.Parameters.Add(new SqlParameter("@g", gname));
                check2.Parameters.Add(new SqlParameter("@s", Std));
                SqlParameter success2 = check2.Parameters.Add("@o", System.Data.SqlDbType.Int);
                success2.Direction = ParameterDirection.Output;
                conn.Open();
                check2.ExecuteNonQuery();
                conn.Close();

                SqlCommand getId = new SqlCommand("getNid", conn);
                getId.CommandType = CommandType.StoredProcedure;
                getId.Parameters.Add(new SqlParameter("@u", user));
                string nid = "";
                conn.Open();
                SqlDataReader r1 = getId.ExecuteReader(CommandBehavior.CloseConnection);
                while (r1.Read())
                {
                    nid = r1.GetString(r1.GetOrdinal("NationalID"));
                }
                
                conn.Close();
                if (hname == "" || gname == "" || success2.Value.ToString() == "0")
                {
                    Response.Write("Match not available");
                }
                else
                {
                    SqlCommand buyticketproc = new SqlCommand("purchaseTicket", conn);
                    buyticketproc.CommandType = CommandType.StoredProcedure;
                    buyticketproc.Parameters.Add(new SqlParameter("@n", nid));
                    buyticketproc.Parameters.Add(new SqlParameter("@h", hname));
                    buyticketproc.Parameters.Add(new SqlParameter("@g", gname));
                    buyticketproc.Parameters.Add(new SqlParameter("@t", Std));
                    conn.Open();
                    buyticketproc.ExecuteNonQuery();
                    conn.Close();
                    Response.Write("Ticket bought");
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);
            string St = stf.Text;

            DateTime Std =
                DateTime.ParseExact(St, "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);
            conn.Open();


            SqlCommand buyticketproc = new SqlCommand("select c1.name as host,c2.name as guest,s.name as stadium,s.location from match m inner join club c1 on c1.id=m.hostId inner join club c2 on c2.id=m.guestId inner join stadium s on m.stadiumId=s.id where m.startTime= CONVERT(datetime,'" + Std+"') and exists(select * from ticket t where t.matchId=m.id and t.status=1 )", conn);


            SqlDataReader r = buyticketproc.ExecuteReader(CommandBehavior.CloseConnection);
            while (r.Read())
            {
                string cr = r.GetString(r.GetOrdinal("stadium"));
                string h = r.GetString(r.GetOrdinal("host"));
                string g = r.GetString(r.GetOrdinal("guest"));
                string l = r.GetString(r.GetOrdinal("Location"));
                Label loc = new Label();
                Label name = new Label();
                Label cid = new Label();
                Label cap = new Label();

                name.Text = " " + h + " VS ";
                loc.Text = g + " ";
                cid.Text = cr + " ";
                cap.Text = l + " ";
                

                form1.Controls.Add(name);
                form1.Controls.Add(loc);
                form1.Controls.Add(cid);
                form1.Controls.Add(cap);
             
            }

        }
    
    }
}