﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;

namespace GUCDB
{
    public partial class FanReg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            {
                string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
                SqlConnection conn = new SqlConnection(CONNSTR);
                string name = fname.Text;
                string username = funame.Text;
                string password = fpass.Text;
                string nid = fnid.Text;
                int phone = Int32.Parse(fpn.Text);
                string birthdate = fbd.Text;
                string address = fadd.Text;
                DateTime fbdd =
                DateTime.ParseExact(birthdate, "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);
                SqlCommand check = new SqlCommand("checkUser", conn);
                check.CommandType = CommandType.StoredProcedure;
                check.Parameters.Add(new SqlParameter("@u", username));
                SqlParameter success = check.Parameters.Add("@o", System.Data.SqlDbType.Int);
                success.Direction = ParameterDirection.Output;
                conn.Open();
                check.ExecuteNonQuery();
                conn.Close();

                SqlCommand check2= new SqlCommand("checkFan", conn);
                check.CommandType = CommandType.StoredProcedure;
                check.Parameters.Add(new SqlParameter("@id", nid));
                SqlParameter success2 = check2.Parameters.Add("@o", System.Data.SqlDbType.Int);
                success2.Direction = ParameterDirection.Output;
                conn.Open();
                check2.ExecuteNonQuery();
                conn.Close();

                if (name == "" || password == "" || username == "" || nid == "" || phone == 0 || birthdate == "" || address == ""||success.Value.ToString()=="0"|| success2.Value.ToString() == "1")
                {
                    Response.Write("invalid username or repeated national id");
                }
                else
                {
                    SqlCommand addFanproc = new SqlCommand("addFan", conn);
                    addFanproc.CommandType = CommandType.StoredProcedure;
                    addFanproc.Parameters.Add(new SqlParameter("@n", name));
                    addFanproc.Parameters.Add(new SqlParameter("@u", username));
                    addFanproc.Parameters.Add(new SqlParameter("@p", password));
                    addFanproc.Parameters.Add(new SqlParameter("@id", nid));
                    addFanproc.Parameters.Add(new SqlParameter("@b", fbdd));
                    addFanproc.Parameters.Add(new SqlParameter("@a", address));
                    addFanproc.Parameters.Add(new SqlParameter("@ph", phone));
                    conn.Open();
                    addFanproc.ExecuteNonQuery();
                    conn.Close();
                    Response.Redirect("Fan.aspx");
                }
            }
        }
    }
}