﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace GUCDB
{
    public partial class StadiumManager : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            {
                string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
                SqlConnection conn = new SqlConnection(CONNSTR);
                string user = Session["user"].ToString();

                string hname = accreqhname.Text;
                string gname = accreqgname.Text;
                string St = accreqstime.Text;
                SqlCommand check = new SqlCommand("checkClub", conn);
                check.CommandType = CommandType.StoredProcedure;
                check.Parameters.Add(new SqlParameter("@n", hname));
                SqlParameter success = check.Parameters.Add("@o", System.Data.SqlDbType.Int);
                success.Direction = ParameterDirection.Output;
                conn.Open();
                check.ExecuteNonQuery();
                conn.Close();

                SqlCommand check2 = new SqlCommand("checkClub", conn);
                check2.CommandType = CommandType.StoredProcedure;
                check2.Parameters.Add(new SqlParameter("@n", gname));
                SqlParameter success2 = check2.Parameters.Add("@o", System.Data.SqlDbType.Int);
                success2.Direction = ParameterDirection.Output;
                conn.Open();
                check2.ExecuteNonQuery();
                conn.Close();

                SqlCommand check3 = new SqlCommand("checkReq", conn);
                check3.CommandType = CommandType.StoredProcedure;
                check3.Parameters.Add(new SqlParameter("@nh", hname));
                check3.Parameters.Add(new SqlParameter("@ng", gname));
                SqlParameter success3 = check3.Parameters.Add("@o", System.Data.SqlDbType.Int);
                success3.Direction = ParameterDirection.Output;
                conn.Open();
                check3.ExecuteNonQuery();
                conn.Close();

                DateTime Std =
                    DateTime.ParseExact(St, "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);
                if (success3.Value.ToString() == "0")
                {
                    Response.Write("Request not available");
                }
                else
                {
                    if (hname == "" || gname == "" || user == "" || success.Value.ToString() == "0" || success2.Value.ToString() == "0")
                    {
                        Response.Write("clubs not available");
                    }
                    else
                    {
                        SqlCommand Accreqproc = new SqlCommand("acceptRequest", conn);
                        Accreqproc.CommandType = CommandType.StoredProcedure;

                        Accreqproc.Parameters.Add(new SqlParameter("@h", hname));
                        Accreqproc.Parameters.Add(new SqlParameter("@g", gname));
                        Accreqproc.Parameters.Add(new SqlParameter("@u", user));
                        Accreqproc.Parameters.Add(new SqlParameter("@t", Std));
                        conn.Open();
                        Accreqproc.ExecuteNonQuery();
                        conn.Close();
                        Response.Write("Request accepted");
                    }
                }
            }

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            {
                {
                    string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
                    SqlConnection conn = new SqlConnection(CONNSTR);
                    string user = Session["user"].ToString();
                    string rejhname = rejreqhname.Text;
                    string rejgname = rejreqgname.Text;
                    string rejSt = rejreqstime.Text;
                    SqlCommand check = new SqlCommand("checkClub", conn);
                    check.CommandType = CommandType.StoredProcedure;
                    check.Parameters.Add(new SqlParameter("@n", rejhname));
                    SqlParameter success = check.Parameters.Add("@o", System.Data.SqlDbType.Int);
                    success.Direction = ParameterDirection.Output;
                    conn.Open();
                    check.ExecuteNonQuery();
                    conn.Close();

                    SqlCommand check2 = new SqlCommand("checkClub", conn);
                    check2.CommandType = CommandType.StoredProcedure;
                    check2.Parameters.Add(new SqlParameter("@n", rejgname));
                    SqlParameter success2 = check2.Parameters.Add("@o", System.Data.SqlDbType.Int);
                    success2.Direction = ParameterDirection.Output;
                    conn.Open();
                    check2.ExecuteNonQuery();
                    conn.Close();

                    SqlCommand check3 = new SqlCommand("checkReq", conn);
                    check3.CommandType = CommandType.StoredProcedure;
                    check3.Parameters.Add(new SqlParameter("@nh", rejhname));
                    check3.Parameters.Add(new SqlParameter("@ng", rejgname));
                    SqlParameter success3 = check3.Parameters.Add("@o", System.Data.SqlDbType.Int);
                    success3.Direction = ParameterDirection.Output;
                    conn.Open();
                    check3.ExecuteNonQuery();
                    conn.Close();

                    DateTime RStd =
                        DateTime.ParseExact(rejSt, "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);
                    if (success3.Value.ToString() == "0")
                    {
                        Response.Write("Request not available");
                    }
                    else
                    {
                        if (rejhname == "" || rejgname == "" || user == "" || success.Value.ToString() == "0" || success2.Value.ToString() == "0")
                        {
                            Response.Write("Request not available");
                        }
                        else
                        {
                            SqlCommand rejreqproc = new SqlCommand("rejectRequest", conn);
                            rejreqproc.CommandType = CommandType.StoredProcedure;

                            rejreqproc.Parameters.Add(new SqlParameter("@h", rejhname));
                            rejreqproc.Parameters.Add(new SqlParameter("@g", rejgname));
                            rejreqproc.Parameters.Add(new SqlParameter("@u", user));
                            rejreqproc.Parameters.Add(new SqlParameter("@t", RStd));
                            conn.Open();
                            rejreqproc.ExecuteNonQuery();
                            conn.Close();
                            Response.Write("Request rejected");
                        }
                    }
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);

            string user = Session["user"].ToString();

            SqlCommand getId = new SqlCommand("getStadiumId", conn);
            getId.CommandType = CommandType.StoredProcedure;
            getId.Parameters.Add(new SqlParameter("@u", user));
            string s_name = "";
            conn.Open();
            SqlDataReader r1 = getId.ExecuteReader(CommandBehavior.CloseConnection);
            while (r1.Read())
            {
                s_name = r1.GetString(r1.GetOrdinal("name"));
            }
            // Response.Write(c_id);
            conn.Close();
            SqlCommand viewMatch = new SqlCommand("select * from stadium  where name='" + s_name + "'", conn);

            conn.Open();




            SqlDataReader r = viewMatch.ExecuteReader(CommandBehavior.CloseConnection);
            while (r.Read())
            {
                string l = r.GetString(r.GetOrdinal("location"));
                string n = r.GetString(r.GetOrdinal("name"));
                int id = r.GetInt32(r.GetOrdinal("id"));
                int capa = r.GetInt32(r.GetOrdinal("capacity"));
                Label loc = new Label();
                Label name = new Label();
                Label cid = new Label();
                Label cap = new Label();
                loc.Text = l + " ";
                name.Text = " " + n + " ";
                cid.Text = id.ToString() + " ";
                cap.Text = capa.ToString() + " ";


                form1.Controls.Add(name);
                form1.Controls.Add(loc);
                form1.Controls.Add(cid);
                form1.Controls.Add(cap);
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);

            string user = Session["user"].ToString();
            SqlCommand view = new SqlCommand("select r.name as clubRepr, ch.name as host,cg.name as guest,m.startTime,m.endTime from hostRequest h inner join stadiumManager sm on sm.id=h.stadiumManagerId \r\ninner join match m on m.id=h.matchId \r\ninner join club ch on ch.id=m.HostId \r\ninner join club cg on cg.id=m.guestId\r\ninner join clubRepresentative r on r.id=h.ClubReprId\r\nwhere sm.username ='" + user + "'", conn);

            conn.Open();




            SqlDataReader r = view.ExecuteReader(CommandBehavior.CloseConnection);
            while (r.Read())
            {
                string cr = r.GetString(r.GetOrdinal("clubRepr"));
                string h = r.GetString(r.GetOrdinal("host"));
                string g = r.GetString(r.GetOrdinal("guest"));
                DateTime s = r.GetDateTime(r.GetOrdinal("startTime"));
                DateTime en = r.GetDateTime(r.GetOrdinal("endTime"));
                Label loc = new Label();
                Label name = new Label();
                Label cid = new Label();
                Label cap = new Label();
                Label capa = new Label();
                loc.Text = h + " ";
                name.Text = " " + cr + " ";
                cid.Text = g + " ";
                cap.Text = s.ToString() + " ";
                capa.Text = en.ToString();


                form1.Controls.Add(name);
                form1.Controls.Add(loc);
                form1.Controls.Add(cid);
                form1.Controls.Add(cap);
                form1.Controls.Add(capa);
            }
        }
    }
}