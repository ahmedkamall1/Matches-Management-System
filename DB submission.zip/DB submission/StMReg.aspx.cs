﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GUCDB
{
    public partial class StMReg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            {
                string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
                SqlConnection conn = new SqlConnection(CONNSTR);
                string name = StMname.Text;
                string username = StMuname.Text;
                string password = StMpass.Text;
                string stadium = StMsname.Text;
                SqlCommand check = new SqlCommand("checkUser", conn);
                check.CommandType = CommandType.StoredProcedure;
                check.Parameters.Add(new SqlParameter("@u", username));
                SqlParameter success = check.Parameters.Add("@o", System.Data.SqlDbType.Int);
                success.Direction = ParameterDirection.Output;
                conn.Open();
                check.ExecuteNonQuery();
                conn.Close();


                if (name == "" || password == "" || username == "" || stadium==""||success.Value.ToString()=="0")
                {
                    Response.Write("invalid username");
                }
                else
                {
                    SqlCommand addStadiumManager = new SqlCommand("addStadiumManager", conn);
                    addStadiumManager.CommandType = CommandType.StoredProcedure;
                    addStadiumManager.Parameters.Add(new SqlParameter("@n", name));
                    addStadiumManager.Parameters.Add(new SqlParameter("@s", stadium));
                    addStadiumManager.Parameters.Add(new SqlParameter("@u", username));
                    addStadiumManager.Parameters.Add(new SqlParameter("@p", password));
                    conn.Open();
                    addStadiumManager.ExecuteNonQuery();
                    conn.Close();
                    Response.Redirect("StadiumManager.aspx");
                }
            }
        }
    }
}