﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GUCDB
{
    
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void LOGIN(object sender, EventArgs e)
        {
            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);
            string username = Username.Text;
            string password = Password.Text;
            Session["user"] = username;
            SqlCommand loginproc = new SqlCommand("login",conn);
            loginproc.CommandType = CommandType.StoredProcedure;
            loginproc.Parameters.Add(new SqlParameter("@username", username));
            loginproc.Parameters.Add(new SqlParameter("@password", password));
            SqlParameter success = loginproc.Parameters.Add("@success", System.Data.SqlDbType.Int);
            SqlParameter type = loginproc.Parameters.Add("@type", System.Data.SqlDbType.Int);
           
            success.Direction = ParameterDirection.Output;
            type.Direction = ParameterDirection.Output;
            conn.Open();
            loginproc.ExecuteNonQuery();
            conn.Close();

            if(success.Value.ToString()=="1")
            {
                if(type.Value.ToString()=="5")
                    {
                    Response.Redirect("System Admin.aspx");
                }
                if (type.Value.ToString() == "2")
                {
                    Response.Redirect("AssocManager.aspx");
                }
                if (type.Value.ToString() == "4")
                {
                    Response.Redirect("ClubRep.aspx");
                }
                if (type.Value.ToString() == "3")
                {
                    Response.Redirect("StadiumManager.aspx");
                }
                if (type.Value.ToString() == "1")
                {
                    Response.Redirect("Fan.aspx");
                }
            }
            
        }

        protected void register_Click(object sender, EventArgs e)
        {
            Response.Redirect("regPage.aspx");
        }
    }
}