﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;


namespace GUCDB
{
    public partial class System_Admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void addClubClick(object sender, EventArgs e)
        {
            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);

            string name = clubName.Text;
            Label error = new Label();

            string loc = clubLocation.Text;
            if (name == "" || loc == "")
            {
                error.Text = "Club not entered";
                form1.Controls.Add(error);
            }
            else
            {

                SqlCommand addclubproc = new SqlCommand("addClub", conn);
                addclubproc.CommandType = CommandType.StoredProcedure;
                addclubproc.Parameters.Add(new SqlParameter("@N", name));
                addclubproc.Parameters.Add(new SqlParameter("@L", loc));
                conn.Open();
                addclubproc.ExecuteNonQuery();
                conn.Close();
                error.Text = "Club Entered";
                form1.Controls.Add(error);
            }

        }

        protected void deleteClub_Click(object sender, EventArgs e)
        {
            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);
            string name = CND.Text;
            string name1 = clubName.Text;
            Label error = new Label();

            if (name == "")
            {
                error.Text = "Club not deleted";
                form1.Controls.Add(error);
            }
            else
            {
                SqlCommand deleteclubproc = new SqlCommand("deleteClub", conn);
                deleteclubproc.CommandType = CommandType.StoredProcedure;
                deleteclubproc.Parameters.Add(new SqlParameter("@N", name));
                conn.Open();
                deleteclubproc.ExecuteNonQuery();
                conn.Close();
                error.Text = "Club deleted";
                form1.Controls.Add(error);
            }
        }

        protected void clubName_TextChanged(object sender, EventArgs e)
        {

        }

        protected void AddSt_Click(object sender, EventArgs e)
        {
            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);
            string name = STNA.Text;
            string loc = STLA.Text;
            string cap = STCA.Text;

            string name1 = clubName.Text;
            Label error = new Label();

            if (name == "" || loc == "" || cap == "" )
            {
                error.Text = "stadium not added";
                form1.Controls.Add(error);
            }
            else
            {
                
                int Capacity = int.Parse(STCA.Text);
                if (Capacity <= 0)
                {
                    error.Text = "Capacity must be more than 0";
                    form1.Controls.Add(error);

                }
                else
                {
                    SqlCommand addSTproc = new SqlCommand("addStadium", conn);
                    addSTproc.CommandType = CommandType.StoredProcedure;
                    addSTproc.Parameters.Add(new SqlParameter("@N", name));
                    addSTproc.Parameters.Add(new SqlParameter("@L", loc));
                    addSTproc.Parameters.Add(new SqlParameter("@C", Capacity));
                    conn.Open();
                    addSTproc.ExecuteNonQuery();
                    conn.Close();
                    error.Text = "stadium added";
                    form1.Controls.Add(error);
                }
            }
        }

        protected void DST_Click(object sender, EventArgs e)
        {
            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);
            string name = DSTN.Text;
            string name1 = clubName.Text;
            Label error = new Label();

            if (name == "")
            {
                error.Text = "stadium not deleted";
                form1.Controls.Add(error);
            }
            else
            {
                SqlCommand deleteStproc = new SqlCommand("deleteStadium", conn);
                deleteStproc.CommandType = CommandType.StoredProcedure;
                deleteStproc.Parameters.Add(new SqlParameter("@N", name));
                conn.Open();
                deleteStproc.ExecuteNonQuery();
                conn.Close();
                error.Text = "stadium deleted";
                form1.Controls.Add(error);
            }
        }

        protected void BF_Click(object sender, EventArgs e)
        {
            string CONNSTR = WebConfigurationManager.ConnectionStrings["GUCDB"].ToString();
            SqlConnection conn = new SqlConnection(CONNSTR);
            string id = BFI.Text;
            SqlCommand Accreqproc = new SqlCommand("checkFan", conn);
            Accreqproc.CommandType = CommandType.StoredProcedure;
            string name1 = clubName.Text;
            Label error = new Label();
            if (id== "")
            {
                error.Text = "enter a valid national Id";
                form1.Controls.Add(error);

            }
            else
            {


                Accreqproc.Parameters.Add(new SqlParameter("@id", id));

                SqlParameter type = Accreqproc.Parameters.Add("@o", System.Data.SqlDbType.Int);
                type.Direction = ParameterDirection.Output;
                conn.Open();
                Accreqproc.ExecuteNonQuery();
                conn.Close();
                if (id== null || type.Value.ToString() == "0")
                {
                    error.Text = "enter a valid national Id";
                    form1.Controls.Add(error);

                }
                else
                {
                    SqlCommand BFproc = new SqlCommand("blockFan", conn);
                    BFproc.CommandType = CommandType.StoredProcedure;
                    BFproc.Parameters.Add(new SqlParameter("@Nid", id));
                    conn.Open();
                    BFproc.ExecuteNonQuery();
                    conn.Close();
                    error.Text = "fan blocked";
                    form1.Controls.Add(error);
                }
            }
        }
    }
}